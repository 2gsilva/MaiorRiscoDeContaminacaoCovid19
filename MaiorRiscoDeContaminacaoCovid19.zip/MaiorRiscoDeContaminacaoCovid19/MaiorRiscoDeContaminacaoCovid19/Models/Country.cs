﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaiorRiscoDeContaminacaoCovid19.Models
{
    public class Country
    {
        public int CountryId { get; set; }
        public string Coutry { get; set; }
        public string CountryCode { get; set; }
        public int TotalConfirmed { get; set; }
        public int TotalRecovered { get; set; }
    }
}
