﻿using MaiorRiscoDeContaminacaoCovid19.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;

namespace MaiorRiscoDeContaminacaoCovid19.Service
{
    public class Covid19Api
    {
        private static readonly HttpClient client = new HttpClient();

      //  public  Covid19Api()
      //  {
      //      client = new HttpClient();
      //  }

        public  async Task<List<Country>>  OterPaisesMaisCasos() 
        {
            // client.DefaultRequestHeaders.Accept.Clear();
            // client.DefaultRequestHeaders.Accept.Add(
            //    new MediaTypeWithQualityHeaderValue(""));

            var requisicao = client.GetStreamAsync("https://api.covid19api.com/summary");
            var Countries = await JsonSerializer.DeserializeAsync<List<Country>>(await requisicao);
            return Countries;
        } 
    }
}
